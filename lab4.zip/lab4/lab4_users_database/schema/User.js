const mongoose = require("mongoose");
const { Schema } = mongoose;

const userSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  username: {
    type: String,
    required: true,
    minLength: 4,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    match: /^\S+@\S+\.\S+$/,
  },
  address: {
    street: {
      type: String,
      required: true,
    },
    suite: {
      type: String,
    },
    city: {
      type: String,
      required: true,
      match: /^[a-zA-Z\s]+$/,
    },
    zipcode: {
      type: String,
      required: true,
      match: /^\d{5}-\d{4}$/,
    },
    geo: {
      lat: {
        type: String,
      },
      lng: {
        type: String,
      },
    },
  },
  phone: {
    type: String,
    required: true,
    match: /^1-\d{3}-\d{3}-\d{4}$/,
  },
  website: {
    type: String,
    match: /^(http|https):\/\/\S+$/,
  },
  company: {
    name: {
      type: String,
    },
    catchPhrase: {
      type: String,
    },
    bs: {
      type: String,
    },
  },
});

const User = mongoose.model("User", userSchema);

module.exports = User;
