const express = require("express");
const User = require("../schema/User");
const router = express.Router();

// POST route to create a new user
router.post("/", async (req, res) => {
  try {
    // Create a new user using the User model
    const newUser = new User(req.body);

    // Save the user to the database
    await newUser.save();

    res
      .status(201)
      .json({ message: "User created successfully", user: newUser });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
